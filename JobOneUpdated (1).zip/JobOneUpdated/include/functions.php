<?php
error_reporting(E_ERROR);
session_start();
?>

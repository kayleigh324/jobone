<?php
//changes the server from not secure to secure host which is University of Greenwich.
/*if(empty($_SERVER['HTTPS']) == "off"){
    header('Location: ' .  'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
}*/
//connection that other pages use
//details below
$database_host = 'localhost'; 
$database_user = 'gojobone_user'; 
$database_pass = 'O6ex7ekw&wYO';
$database_name = 'gojobone_db';

$database = mysqli_connect($database_host, $database_user, $database_pass, $database_name);
//if above details are wrong, the message would appear saying it cannot connect
if (mysqli_connect_errno($database)) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
?>